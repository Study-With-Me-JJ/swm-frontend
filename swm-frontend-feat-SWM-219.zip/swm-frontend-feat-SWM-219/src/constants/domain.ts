export const DEV_DOMAIN = {
  API: process.env.NEXT_PUBLIC_API_URL,
  WEB: process.env.NEXT_PUBLIC_BASE_URL,
};

// TODO: 배포 도메인 설정 추가
// export const PROD_DOMAIN = {
//   API: 'https://api.swm-prod.breakti.me:444',
//   WEB: 'https://localhost:3000',
// };
