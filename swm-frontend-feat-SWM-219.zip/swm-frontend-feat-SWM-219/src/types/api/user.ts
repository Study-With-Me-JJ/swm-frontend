export interface User {
    nickname: string;
    password: string;
    name: string;
    loginId: string;
  }