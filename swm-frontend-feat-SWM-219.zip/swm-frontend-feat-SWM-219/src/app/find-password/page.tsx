export default function FindPassword() {
    return <div>비밀번호 찾기 페이지</div>
  }