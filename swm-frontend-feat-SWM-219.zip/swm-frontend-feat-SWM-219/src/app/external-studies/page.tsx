export default function ExternalStudies() {
  return <div>외부 스터디</div>
}