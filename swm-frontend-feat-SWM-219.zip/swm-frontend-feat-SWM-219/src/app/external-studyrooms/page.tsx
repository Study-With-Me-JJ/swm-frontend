export default function ExternalStudyRooms() {
  return <div>외부 스터디 룸</div>
}