export default function FindId() {
    return <div>아이디 찾기 페이지</div>
  }