interface IconProps {
    color?: string;
    strokeColor?: string; 
}

export default function BookMarkIcon({ color = '#000', strokeColor = '#000'}: IconProps) {
   return (
        // <Image src={'/icons/icon_bookmark_off.svg'} alt='북마크' width={100} height={100} />
        <svg width="30" height="31" viewBox="0 0 30 31" fill={color} xmlns="http://www.w3.org/2000/svg">
        <g clipPath="url(#clip0_320_412)">
        <path d="M6.7625 6.75031V6.75C6.7625 5.64787 7.6544 4.75 8.75 4.75H21.25C22.3489 4.75 23.25 5.65114 23.25 6.75V25.9917L15.197 22.5404L15 22.456L14.803 22.5404L6.75047 25.9915L6.7625 6.75031Z" stroke={strokeColor}/>
        </g>
        <defs>
        <clipPath id="clip0_320_412">
        <rect width="30" height="30" fill="white" transform="translate(0 0.5)"/>
        </clipPath>
        </defs>
        </svg>
        
    )
}