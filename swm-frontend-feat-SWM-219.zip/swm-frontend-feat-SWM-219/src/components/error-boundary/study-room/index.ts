export { StudyRoomErrorBoundary } from './study-room-errorboundary';
export { StudyRoomErrorFallback } from './study-room-error-fallback';
export type { StudyRoomErrorFallbackProps } from './study-room-errorboundary'; 